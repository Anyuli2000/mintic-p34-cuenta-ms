package com.misiontic.futbolinms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FutbolinmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(FutbolinmsApplication.class, args);
	}

}
